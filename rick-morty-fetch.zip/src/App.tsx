import React,{useEffect,useState} from "react";
import {View,Text,FlatList,ActivityIndicator,SafeAreaView,StyleSheet} from "react-native";
import CharacterCard from "./components/CharacterCard";
import {getCharacters} from "./services/api";

export default function App(){
 const [characters,setCharacters]=useState<any[]>([]);
 const [loading,setLoading]=useState(true);

 useEffect(()=>{
  getCharacters()
   .then(setCharacters)
   .finally(()=>setLoading(false));
 },[]);

 if(loading){
  return <View style={styles.loading}><ActivityIndicator size="large"/><Text>Carregando...</Text></View>
 }

 return (
  <SafeAreaView style={styles.container}>
   <Text style={styles.title}>Rick and Morty API</Text>
   <FlatList
    data={characters}
    keyExtractor={(item)=>String(item.id)}
    renderItem={({item})=><CharacterCard item={item}/>}
   />
  </SafeAreaView>
 )
}
const styles=StyleSheet.create({
 container:{flex:1,padding:16},
 title:{fontSize:28,fontWeight:"bold",textAlign:"center",marginBottom:10},
 loading:{flex:1,justifyContent:"center",alignItems:"center"}
});