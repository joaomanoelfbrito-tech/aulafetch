import {View,Text,Image} from "react-native";
export default function CharacterCard({item}:any){
 return(
  <View style={{flexDirection:"row",padding:10,marginBottom:10,backgroundColor:"#fff"}}>
   <Image source={{uri:item.image}} style={{width:80,height:80,borderRadius:40}}/>
   <View style={{marginLeft:10}}>
    <Text>{item.name}</Text>
    <Text>{item.species}</Text>
    <Text>{item.status}</Text>
   </View>
  </View>
 )
}