# Rick and Morty Fetch
Projeto com Fetch + FlatList.